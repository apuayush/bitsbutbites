const express = require("express");
const router = express.Router();
const queryString = require("querystring");
const multer = require("multer");
const path = require("path");

const fileOps = require("../utilities/fileOperations");

const uploadDest = "public/uploads/";
const jdFile = "public/uploads/jds.json";
const selectedFile = "public/uploads/selected.json";

const storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, uploadDest);
  },
  filename: function(req, file, cb) {
    cb(null, file.fieldname + "-" + Date.now() + ".pdf");
  }
});

const maxSize = 5 * 1024 * 1024;
const upload = multer({
  storage: storage,
  limits: { fileSize: maxSize },
  fileFilter: function(req, file, cb) {
    var filetypes = /pdf/;
    var mimetype = filetypes.test(file.mimetype);

    var extname = filetypes.test(path.extname(file.originalname).toLowerCase());

    if (mimetype && extname) {
      return cb(null, true);
    }

    cb(
      "Error: File upload only supports the " +
        "following filetype - " +
        filetypes
    );
  }
});

router
  .route("/")
  .get(function(req, res, next) {
    let data = fileOps.readFromFileSync(jdFile);
    if (data == undefined || data == null || data == "") data = {};
    else data = JSON.parse(data);
    res.render("home", { jds: data });
  })
  .post(function(req, res, next) {
    let formData = req.body;
    let keys = Object.keys(formData);
    let i = 0;
    selectedJD = {};
    while (i < keys.length) {
      if (!keys[i].includes("counter") && formData[keys[i]] === "on") {
        if (keys[i + 1].includes(keys[i]) && formData[keys[i + 1]] !== "") {
          selectedJD = { ...selectedJD, [keys[i]]: formData[keys[i + 1]] };
          i += 1;
        }
      }
      i += 1;
    }
    fileOps.writeToFile(selectedFile, JSON.stringify(selectedJD));
    let query = queryString.stringify(Object.keys(selectedJD));
    res.redirect("/uploadResume?" + query);
  });

router
  .route("/addJob")
  .get(function(req, res, next) {
    if (req.query.error !== undefined)
      res.render("addJD", { error: req.query.error });
    else res.render("addJD");
  })
  .post(function(req, res, next) {
    let formData = req.body;
    let response = "";

    let existingData = fileOps.readFromFileSync(jdFile);
    if (existingData == undefined || existingData == null || existingData == "")
      existingData = {};
    else existingData = JSON.parse(existingData);

    let keys = Object.keys(formData);
    for (let i = 0; i < keys.length; i += 2) {
      let title = formData[keys[i]];
      let desc = formData[keys[i + 1]];
      existingData = { ...existingData, [title]: desc };
    }
    fileOps.writeToFile(jdFile, JSON.stringify(existingData));
    res.redirect("/");
  });

router
  .route("/uploadResume")
  .get(function(req, res, next) {
    if (Object.keys(req.query).length !== 0)
      res.render("uploadResume", { selected: req.query });
    else res.render("uploadResume");
  })
  .post(upload.array("Resumes", 100), function(req, res, next) {
    const files = req.files;
    if (!files) {
      const error = new Error("Please choose files");
      error.httpStatusCode = 400;
      return next(error);
    }
    res.send("Calling service");
  });

module.exports = router;
