let id = 1;
function addToForm() {
  let form = document.getElementById("form");

  id++;

  let formRow = document.createElement("div");
  formRow.classList.add("form-row");

  let inputLabelTitle = document.createElement("div");
  inputLabelTitle.classList.add("label-input");
  let col25Title = document.createElement("div");
  col25Title.classList.add("col-25");
  let col75Title = document.createElement("div");
  col75Title.classList.add("col-75");
  let labelTitle = document.createElement("label");
  labelTitle.for = "title" + id;
  labelTitle.innerHTML = "Job Title:";
  let inputTitle = document.createElement("input");
  inputTitle.id = "title" + id;
  inputTitle.type = "text";
  inputTitle.name = "title" + id;
  inputTitle.placeholder = "Title...";
  col25Title.appendChild(labelTitle);
  col75Title.appendChild(inputTitle);
  inputLabelTitle.appendChild(col25Title);
  inputLabelTitle.appendChild(col75Title);

  let inputLabelDesc = document.createElement("div");
  inputLabelDesc.classList.add("label-input");
  let col25Desc = document.createElement("div");
  col25Desc.classList.add("col-25");
  let col75Desc = document.createElement("div");
  col75Desc.classList.add("col-75");
  let labelDesc = document.createElement("label");
  labelDesc.innerHTML = "Description:";
  labelDesc.for = "desc" + id;
  let textareaDesc = document.createElement("textarea");
  textareaDesc.id = "desc" + id;
  textareaDesc.name = "desc" + id;
  textareaDesc.placeholder = "Add your description...";
  col25Desc.appendChild(labelDesc);
  col75Desc.appendChild(textareaDesc);
  inputLabelDesc.appendChild(col25Desc);
  inputLabelDesc.appendChild(col75Desc);

  formRow.appendChild(inputLabelTitle);
  formRow.appendChild(inputLabelDesc);
  form.insertBefore(formRow, form.childNodes[form.childNodes.length - 2]);
}
