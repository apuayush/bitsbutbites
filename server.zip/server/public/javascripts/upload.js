updateList = () => {
  const input = document.getElementById("file");
  const output = document.getElementById("fileList");

  let text = "<ol>";
  for (let i = 0; i < input.files.length; i++) {
    text += "<li>" + input.files.item(i).name + "</li>";
  }
  text += "</ol>";
  text += "<input type='submit' value='Get Output'>";
  output.classList.remove("greyed-out");
  output.innerHTML = text;
};

validateFiles = () => {
  const input = document.getElementById("file");
  const allowedExtensions = /(\.pdf)$/i;
  for (let i = 0; i < input.files.length; i++) {
    const fsize = input.files.item(i).size;
    const file = Math.round(fsize / 1024);
    // The size of the file.
    if (!allowedExtensions.exec(input.files.item(i).name)) {
      alert("Invalid file type detected");
      input.value = "";
      return false;
    }
    if (file >= 5120) {
      alert("File too Big, please select a file less than 5mb");
      input.value = "";
      return false;
    }
  }
  updateList();
};
