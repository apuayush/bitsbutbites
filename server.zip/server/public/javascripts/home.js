function toggle(id) {
  let element = document.getElementById(id);
  if (element.classList.contains("hidden")) element.classList.remove("hidden");
  else {
    element.classList.add("hidden");
    element.childNodes[1].value = 0;
  }
}
