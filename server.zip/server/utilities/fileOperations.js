const fs = require("fs");

const writeToFile = (filePath, data) => {
  fs.writeFile(filePath, data, function(err) {
    if (err) {
      return err;
    }
  });
};

const appendToFile = (filePath, data) => {
  fs.appendFile(filePath, data, function(err) {
    if (err) {
      return err;
    }
  });
};

const readFromFile = filePath => {
  fs.readFile(filePath, function(err, data) {
    if (err) {
      return err;
    }
    return data;
  });
};

const readFromFileSync = filePath => {
  return fs.readFileSync(filePath, "utf-8");
};

module.exports = { writeToFile, appendToFile, readFromFile, readFromFileSync };
